package atmmachine;
import java.util.Scanner;

class BankAccount
{
	int balance;
	int previousTranscation;
	String CustomerName;
	int CustomerPasswordId;
	BankAccount(String cname,int cid)
	{
		CustomerName = cname;
		CustomerPasswordId=cid;
	}
	
	void deposit(int amount)
	{
		if(amount !=0)
		{
			balance= balance + amount;
			previousTranscation = amount;
		}
		
	}
	void withdraw(int amount)
	{
		if(amount !=0)
		{
			balance = balance - amount;
			previousTranscation = -amount;
			
		}
	}
	void getpreviousTranscation()
	{
		if(previousTranscation > 0)
		{
			System.out.println("Deposited: "+previousTranscation);	
		}
		else if(previousTranscation < 0)
		{
			System.out.println("withdraw: "+Math.abs(previousTranscation));			
		}
		else
		{
		System.out.println("No transcation occured");
		}
	}
	void showMenu()
	{
		char option='\0';
		Scanner Scanner = new Scanner(System.in);
		
		System.out.println("Welcome to TATA BANK");
		System.out.println("Your name is "+CustomerName);
		System.out.println("your passwordId is "+CustomerPasswordId);
		System.out.println("\n");
		System.out.println("A. Check Balance");
		System.out.println("B. Deposit");
		System.out.println("C. Withdraw");
		System.out.println("D. Previous transcation");
		System.out.println("E. Exit");
		
		do
		{
			
			System.out.println("Enter an option");
			
			option = Scanner.next().charAt(0);
			System.out.println("\n");
			
			switch(option)
			{
		    
			
			case'A':
				System.out.println("Balance = "+ balance);
				System.out.println("\n");
				break;
			case'B':
				System.out.println("Enter an amount to deposit:");
		        int amount = Scanner.nextInt();
				deposit(amount);
				System.out.println("\n");
				break;
			case'C':
				System.out.println("Enter an amount to withdraw");
				int amount2 = Scanner.nextInt();
				withdraw(amount2 );
				System.out.println("\n");
				break;
			case 'D':
				getpreviousTranscation();
				System.out.println("\n");
				break;
			case 'E':
				System.out.println("Take your card");
				break;
			
			default:
				System.out.println("Invalid option");
				System.out.println("please enter again");
				break;
			}
			
		}
				while(option  !='E');
			System.out.println("Thankyou for using our bank services");
	}
}
public class Machine {
	public static void main(String[] args) {
		BankAccount obj1 = new BankAccount("Marvel",1234);
		obj1.showMenu();
		
	}

}		
	







	
	

		
		
	

